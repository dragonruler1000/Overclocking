require "util"

require "prototypes.item"
require "prototypes.entity.resources"
require "prototypes.particles"
require "prototypes.recipe"
require "prototypes.item-groups"
require "prototypes.autoplace-controls"
require "prototypes.entity.entities"