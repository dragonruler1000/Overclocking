require("util")
local hit_effects = require("__base__.prototypes.entity.hit-effects")

data:extend({
    {
        type = "beacon",
        name = "oc-tower",
        icon = "__base__/graphics/icons/beacon.png",
        flags = { "placeable-player", "player-creation" },
        minable = { mining_time = 0.2, result = "oc_tower" },
        fast_replaceable_group = "oc_tower",
        max_health = 2000,
        corpse = "beacon-remnants",
        dying_explosion = "beacon-explosion",
        collision_box = { { -1.2, -1.2 }, { 1.2, 1.2 } },
        selection_box = { { -1.5, -1.5 }, { 1.5, 1.5 } },
        damaged_trigger_effect = hit_effects.entity(),
        drawing_box_vertical_extension = 0.7,
        allowed_effects = { "consumption", "speed", "pollution", "productivity" },
        graphics_set = require("__base__.prototypes.entity.beacon-animations"),
        radius_visualisation_picture = {
            filename = "__base__/graphics/entity/beacon/beacon-radius-visualization.png",
            priority = "extra-high-no-scale",
            width = 10,
            height = 10
        },
        supply_area_distance = 3,
        energy_source = {
            type = "electric",
            usage_priority = "secondary-input"
        },
        impact_category = "metal",
        open_sound = { filename = "__base__/sound/open-close/beacon-open.ogg", volume = 0.25 },
        close_sound = { filename = "__base__/sound/open-close/beacon-close.ogg", volume = 0.25 },
        working_sound = {
            sound = {
                variations = sound_variations("__base__/sound/beacon", 2, 0.3),
                audible_distance_modifier = 0.33
            },
            max_sounds_per_prototype = 3
        },
        energy_usage = "480kW",
        distribution_effectivity = 1.5,
        distribution_effectivity_bonus_per_quality_level = 0.2,
        profile = {
            1, 0.7071, 0.5773, 0.5, 0.4472, 0.4082, 0.3779, 0.3535, 0.3333, 0.3162, 0.3015, 0.2886, 0.2773, 0.2672,
            0.2581, 0.25, 0.2425, 0.2357, 0.2294, 0.2236, 0.2182, 0.2132, 0.2085, 0.2041, 0.2, 0.1961, 0.1924, 0.1889,
            0.1856, 0.1825, 0.1796, 0.1767, 0.174, 0.1714, 0.169, 0.1666, 0.1643, 0.1622, 0.1601, 0.1581, 0.1561, 0.1543,
            0.1524, 0.1507, 0.149, 0.1474, 0.1458, 0.1443, 0.1428, 0.1414, 0.14, 0.1386, 0.1373, 0.136, 0.1348, 0.1336,
            0.1324, 0.1313, 0.1301, 0.129, 0.128, 0.127, 0.1259, 0.125, 0.124, 0.123, 0.1221, 0.1212, 0.1203, 0.1195,
            0.1186, 0.1178, 0.117, 0.1162, 0.1154, 0.1147, 0.1139, 0.1132, 0.1125, 0.1118, 0.1111, 0.1104, 0.1097,
            0.1091, 0.1084, 0.1078, 0.1072, 0.1066, 0.1059, 0.1054, 0.1048, 0.1042, 0.1036, 0.1031, 0.1025, 0.102,
            0.1015, 0.101, 0.1005, 0.1
        },
        beacon_counter = "same_type",
        module_slots = 2,
        icons_positioning = {
            {
                inventory_index = defines.inventory.beacon_modules,
                shift = { 0, 0 },
                multi_row_initial_height_modifier = -0.3,
                max_icons_per_row = 2
            }
        },
        water_reflection = {
            pictures = {
                filename = "__base__/graphics/entity/beacon/beacon-reflection.png",
                priority = "extra-high",
                width = 18,
                height = 29,
                shift = util.by_pixel(0, 55),
                variation_count = 1,
                scale = 5
            },
            rotate = false,
            orientation_to_variation = false
        }
    }
})
